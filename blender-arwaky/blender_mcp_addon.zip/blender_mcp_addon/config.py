import os
import tempfile


def get_config(key: str, default=None):
    """
    Get configuration value from environment or return default.
    Supports dot notation like 'storage.temp_dir'.
    Environment variables are prefixed with BLENDERMCP_ and uppercase.
    Example: BLENDERMCP_STORAGE_TEMP_DIR overrides storage.temp_dir.
    """
    # Convert dot notation to env var name: storage.temp_dir -> BLENDERMCP_STORAGE_TEMP_DIR
    parts = key.split(".")
    env_key = "BLENDERMCP_" + "_".join(p.upper() for p in parts)
    env_val = os.getenv(env_key)
    if env_val is not None:
        return env_val

    # Built-in defaults
    if key == "storage.temp_dir":
        return tempfile.gettempdir()
    if key == "storage.polyhaven_dir":
        poly_dir = os.path.join(tempfile.gettempdir(), "polyhaven")
        os.makedirs(poly_dir, exist_ok=True)
        return poly_dir
    if key == "blender.port":
        return 9876
    if key == "hunyuan.api_url":
        return "http://localhost:8081"

    return default
